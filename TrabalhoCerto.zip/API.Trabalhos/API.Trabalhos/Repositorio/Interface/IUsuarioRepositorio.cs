﻿using API.Trabalho.Model;

namespace API.Trabalho.Repositorio.Interface
{

    public interface IUsuarioRepositorio
    {
        Task<List<UsuariosModel>> BuscarTodosUsuarios();
        Task<UsuariosModel> BuscarPorId(int id);
        Task<UsuariosModel> Adicionar(UsuariosModel usuario);
        Task<UsuariosModel> Atualizar(UsuariosModel usuario, int id);
        Task<bool> Apagar(int id);

    }
}