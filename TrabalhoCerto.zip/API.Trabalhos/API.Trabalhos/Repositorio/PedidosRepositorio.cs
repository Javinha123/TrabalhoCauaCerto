﻿using Microsoft.EntityFrameworkCore;
using API.Trabalho.Data;
using API.Trabalho.Model;
using API.Trabalho.Repositorio.Interface;

namespace API.Trabalho.Repositorio
{
    public class PedidosRepositorio : IPedidosRepositorio
    {
        private readonly CauaDbContext _dbContext;

        public PedidosRepositorio(CauaDbContext cauaDbContext)
        {
            _dbContext = cauaDbContext;
        }

        public async Task<PedidosModel> BuscarPorId(int id)
        {
            return await _dbContext.Pedidos
                .Include(x => x.UsuarioId)
                .FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<PedidosModel>> BuscarTodosPedidos()
        {
            return await _dbContext.Pedidos
                .Include(x => x.Usuario)
                .ToListAsync();
        }
        public async Task<PedidosModel> Adicionar(PedidosModel pedidos)
        {
            await _dbContext.Pedidos.AddAsync(pedidos);
            await _dbContext.SaveChangesAsync();

            return pedidos;
        }
        public async Task<PedidosModel> Atualizar(PedidosModel pedidos, int id)
        {
            PedidosModel pedidosPorId = await BuscarPorId(id);
            if (pedidosPorId == null)
            {
                throw new Exception($"Pedido do ID: {id} nao foi encontrado");
            }
            pedidosPorId.EnderecoEntrega = pedidos.EnderecoEntrega;



            _dbContext.Pedidos.Update(pedidosPorId);
            await _dbContext.SaveChangesAsync();
            return pedidosPorId;
        }

        public async Task<bool> Apagar(int id)
        {
            PedidosModel pedidosPorId = await BuscarPorId(id);
            if (pedidosPorId == null)
            {
                throw new Exception("Pedidos nao encontrados");
            }
            _dbContext.Pedidos.Remove(pedidosPorId);
            await _dbContext.SaveChangesAsync();

            return true;
        }
    }
}
