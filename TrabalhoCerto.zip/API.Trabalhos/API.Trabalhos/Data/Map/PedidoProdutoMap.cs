﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using API.Trabalho.Model;

namespace API.Trabalho.Data.Map
{
    public class PedidoProdutoMap : IEntityTypeConfiguration<PedidoProdutoModel>
    {
        public void Configure(EntityTypeBuilder<PedidoProdutoModel> builder)
        {
            builder.HasKey(x => x.Id);
            builder.Property(x => x.ProdutoId);
            builder.Property(x => x.CategoriaId);
            builder.Property(x => x.quantidade);



        }
    }
}