﻿
namespace API.Trabalho.Model
{
    public class PedidoProdutoModel
    {
        public int Id { get; set; }
        public int quantidade { get; set; }

        public int? ProdutoId { get; set; }
        public virtual ProdutoModel? Produto { get; set; }

        public int? CategoriaId { get; set; }
        public virtual CategoriaModel? Categoria { get; set; }
    }
}