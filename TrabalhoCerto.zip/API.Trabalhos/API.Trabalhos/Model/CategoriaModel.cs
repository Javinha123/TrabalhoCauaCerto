﻿using API.Trabalho.Enum;

namespace API.Trabalho.Model
{
    public class CategoriaModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }

        public StatusCategoria Status { get; set; }
    }
}